import time
import cv2
import numpy as np
import SPADMap
from flask import Flask, render_template
import os

def new_report(test_report):
    lists = os.listdir(test_report)
    lists.sort(key=lambda fn: os.path.getmtime(test_report + "/" + fn))
    file_new = os.path.join(test_report, lists[-1])
    return file_new
    
def LoadCSV(fn):
	tmp = np.loadtxt(fn, dtype=np.str, delimiter=",")
	data = tmp[0:].astype(np.float)
	return data
	
def WEBclicked():
    cap = cv2.VideoCapture(0)
    ret, frame = cap.read()
    tt = time.strftime('%Y%m%d%H%M%S', time.localtime())
    im_name = './static/T/'+tt+'.png'
    cv2.imwrite(im_name,frame)   
    cap.release()    
    new_img = SPADMap.SPAD_FastVi(im_name)
    hd=np.savetxt('./static/D/'+tt+'.csv',new_img,fmt='%f',delimiter=',')
    return new_img

app = Flask(__name__)
@app.route('/')
def index():
    rlt = WEBclicked()
    my_fn1 = new_report('./static/T')
    my_fn2 = my_fn1.split('/')
    my_fn2 = my_fn2[-1]
    return render_template('main.html',value1=rlt.tolist(),value2=my_fn2,value3=my_fn1)
	
if __name__ == '__main__':   
    print('Init OK!')
    #app.run(debug=True)
    app.run(host='0.0.0.0', port=8080) 

