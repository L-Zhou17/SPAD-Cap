import numpy as np
from skimage import io, filters, morphology, color, transform
import skimage
from skimage.color import rgb2hsv

def SPAD_FastVi(im_name):
    image = io.imread(im_name)
    image = transform.resize(image, (120, 160))
    mask = BKR_mask(image)
    R = image[:,:,0]
    G = image[:,:,1]
    B = image[:,:,2]
	new_img = 22.633662457935344 + R/G*(-72.799591791634070) + R/B*(18.966183015486800) + G/R*(4.145876129026082) + G/B*(-6.540374527989202) + B/R*(-0.304232033311956) + B/G*(32.597856074763590)
    new_img = new_img*mask
    new_img[np.where(np.isnan(new_img))]=-5
    new_img[new_img <= 0] = -5
    new_img[new_img >= 85] = 0
    return new_img
    
def BKR_mask(image):
    hsv_img = rgb2hsv(image) 
    thresh = filters.threshold_otsu(hsv_img[:,:,0])
    mask = (hsv_img[:,:,0] < thresh)*1
    kernel = morphology.disk(2)
    mask = morphology.erosion(mask, kernel)
    return mask